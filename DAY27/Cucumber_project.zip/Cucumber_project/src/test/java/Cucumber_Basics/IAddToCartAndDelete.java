package Cucumber_Basics;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class IAddToCartAndDelete {
WebDriver driver;
	@Given("Ebay website able to add to cart and delete")
	public void ebay_website_able_to_add_to_cart_and_delete() {
		driver = new ChromeDriver();
        driver.get("https://www.ebay.com/");
        driver.manage().window().maximize();
        System.out.println("Pre-requisite: Opened eBay homepage");
	}

	@And("add and delete")
	public void add_and_delete() throws InterruptedException{
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        WebElement search = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("gh-ac")));
        search.clear();
        search.sendKeys("New Sony WH-1000XM5/B Wireless Industry Leading Noise Canceling Bluetooth Headphones");
        search.sendKeys(Keys.ENTER);
        Thread.sleep(2000);

        
        driver.get("https://www.ebay.com/itm/314074071401");

        Thread.sleep(2000);
        for (String win : driver.getWindowHandles()) {
            driver.switchTo().window(win);
        }

        try {
            Thread.sleep(2000);
            driver.findElement(By.id("atcBtn_btn_1")).click();
            Thread.sleep(2000);
        } catch (Exception e) {
            System.out.println("Add to cart button not found.");
        }

        driver.get("https://cart.ebay.com/");
        Thread.sleep(2000);

        try {
            driver.findElement(By.xpath("//button[@data-test-id='cart-remove-item']")).click();
            Thread.sleep(1000);
        } catch (Exception e) {
            System.out.println("Remove button not found.");
        }
    }
	

	@Then("cart empty")
	public void cart_empty() {
	 System.out.println("empty cart");   
	}


}
